﻿using Microsoft.AspNetCore.SignalR;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Parcial3.HUB
{
    public class QueueHub : Hub
    {
        public async Task RequestTurn(string name)
        {
            var turnNumber = QueueManager.AddToQueue(name);
            await Clients.All.SendAsync("UpdateQueue", QueueManager.GetQueue(), QueueManager.GetCurrentTurn());
        }

        public async Task AdvanceTurn()
        {
            QueueManager.AdvanceTurn();
            await Clients.All.SendAsync("UpdateQueue", QueueManager.GetQueue(), QueueManager.GetCurrentTurn());
        }

        public async Task GetQueueState()
        {
            await Clients.Caller.SendAsync("UpdateQueue", QueueManager.GetQueue(), QueueManager.GetCurrentTurn());
        }
    }

    public static class QueueManager
    {
        private static readonly List<(int TurnNumber, string Name)> _queue = new List<(int, string)>();
        private static int _currentTurn = 0;
        private static int _nextTurnNumber = 1;
        private static readonly object _lock = new object();

        public static int AddToQueue(string name)
        {
            lock (_lock)
            {
                var turnNumber = _nextTurnNumber++;
                _queue.Add((turnNumber, name));
                Console.WriteLine($"Añadido turno {turnNumber} para {name}. Cola: {_queue.Count}");
                return turnNumber;
            }
        }
        public static void AdvanceTurn()
        {
            lock (_lock)
            {
                if (_queue.Count > 0)
                {
                    _currentTurn = _queue[0].TurnNumber;
                    _queue.RemoveAt(0);
                }
                else
                {
                    _currentTurn = 0;
                }
            }
        }

        public static List<Turn> GetQueue()
        {
            lock (_lock)
            {
                return new List<Turn>((IEnumerable<Turn>)_queue);
            }
        }

        public static int GetCurrentTurn()
        {
            lock (_lock)
            {
                return _currentTurn;
            }
        }
    }

    public class Turn
    {
        public int TurnNumber { get; set; }
        public string Name { get; set; }
    }

}
