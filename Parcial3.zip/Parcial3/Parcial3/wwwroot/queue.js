﻿// Configurar la conexión con SignalR
const connection = new signalR.HubConnectionBuilder()
    .withUrl("/HUB/QueueHub")
    .configureLogging(signalR.LogLevel.Information)
    .build();

// Iniciar la conexión
async function startConnection() {
    try {
        await connection.start();
        console.log("Conexión con SignalR establecida.");
        await connection.invoke("GetQueueState");
    } catch (err) {
        console.error("Error al conectar con SignalR:", err);
        setTimeout(startConnection, 5000);
    }
}

// Manejar el evento UpdateQueue enviado por el servidor
connection.on("UpdateQueue", (queue, currentTurn) => {
    console.log("Datos recibidos - queue:", queue, "currentTurn:", currentTurn);
    const currentTurnElement = document.getElementById("currentTurn");
    if (currentTurnElement) {
        currentTurnElement.textContent = currentTurn === 0 ? "Ninguno" : currentTurn;
    }

    const queueList = document.getElementById("queueList");
    if (queueList) {
        queueList.innerHTML = "";
        if (queue.length === 0) {
            queueList.innerHTML = "<li>No hay turnos en espera.</li>";
        } else {
            queue.forEach(turn => {
                const li = document.createElement("li");
                li.textContent = `Turno ${turn.turnNumber}: ${turn.name}`;
                queueList.appendChild(li);
            });
        }
    }
});

// Manejar el botón Solicitar Turno
const requestTurnButton = document.getElementById("requestTurnButton");
if (requestTurnButton) {
    requestTurnButton.addEventListener("click", async () => {
        const nameInput = document.getElementById("nameInput");
        const name = nameInput ? nameInput.value.trim() : "";
        if (!name) {
            alert("Por favor, ingresa un nombre.");
            return;
        }
        try {
            await connection.invoke("RequestTurn", name);
            if (nameInput) nameInput.value = "";
            const turnMessage = document.getElementById("turnMessage");
            if (turnMessage) turnMessage.textContent = `Turno solicitado para ${name}.`;
        } catch (err) {
            console.error("Error al solicitar turno:", err);
            alert("No se pudo solicitar el turno. Revisa la conexión.");
        }
    });
} else {
    console.error("Elemento requestTurnButton no encontrado en el DOM.");
}

// Manejar el botón Atender Siguiente Turno
const advanceTurnButton = document.getElementById("advanceTurnButton");
if (advanceTurnButton) {
    advanceTurnButton.addEventListener("click", async () => {
        try {
            await connection.invoke("AdvanceTurn");
        } catch (err) {
            console.error("Error al avanzar turno:", err);
            alert("No se pudo avanzar el turno. Revisa la conexión.");
        }
    });
} else {
    console.error("Elemento advanceTurnButton no encontrado en el DOM.");
}

// Iniciar la conexión al cargar la página
connection.onclose(() => {
    console.log("Conexión cerrada. Intentando reconectar...");
    startConnection();
});

startConnection();